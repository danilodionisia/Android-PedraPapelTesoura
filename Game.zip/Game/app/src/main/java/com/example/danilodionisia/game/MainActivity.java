package com.example.danilodionisia.game;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public int placarPlayer,placarAPP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        placarPlayer = 0;
        placarAPP = 0;
    }


    public void reset(View v){

        placarPlayer = 0;
        placarAPP = 0;
        TextView t = (TextView) findViewById(R.id.txtResultado);
        TextView app = (TextView) findViewById(R.id.txtPlacarAPP);
        TextView player = (TextView) findViewById(R.id.txtPlacarPlayer);

        t.setText("Escolha uma opção");
        app.setText("APP: ");
        player.setText("Você: ");

    }

    public void fechar(View v){
        finishAffinity();
    }

    public void resultado(String escolha){

        String [] jogada = {"Pedra", "Papel", "Tesoura"};

        int n = new Random().nextInt(3);


        ImageView img = (ImageView) findViewById(R.id.imgOpponent);
        TextView t = (TextView) findViewById(R.id.txtResultado);
        TextView app = (TextView) findViewById(R.id.txtPlacarAPP);
        TextView player = (TextView) findViewById(R.id.txtPlacarPlayer);

        String escolhaAPP = jogada[n];

        switch (escolhaAPP){

            case "Pedra":
                img.setImageResource(R.drawable.pedra);
                break;

            case "Papel":
                img.setImageResource(R.drawable.papel);
                break;

            case "Tesoura":
                img.setImageResource(R.drawable.tesoura);
                break;
        }


        if (
                (escolhaAPP == "Pedra" && escolha == "Tesoura") ||
                (escolhaAPP == "Papel" && escolha == "Pedra") ||
                (escolhaAPP == "Tesoura" && escolha == "Papel")
                ) {
            t.setText("O APP ganhou! :(");
            placarAPP++;
            app.setText("APP: " + placarAPP);

        }else if(
                (escolha == "Pedra" && escolhaAPP == "Tesoura") ||
                (escolha == "Papel" && escolhaAPP == "Pedra") ||
                (escolha == "Tesoura" && escolhaAPP == "Papel")
                ){
            t.setText("Você ganhou! :)");
            placarPlayer++;
            player.setText("Você: " + placarPlayer);

        }else{
            t.setText("Vocês emparatam! ;)");
            placarAPP++;
            placarPlayer++;
            app.setText("APP: " + placarAPP);
            player.setText("Você: " + placarPlayer);
        }

    }


    public void escolhaPedra(View v){
        resultado("Pedra");
    }


    public void escolhaPapel(View v){
        resultado("Papel");
    }


    public void escolhaTesoura(View v){
        resultado("Tesoura");
    }


}
